# Coroner - Pirate Language

An example of a mod which replaces localization data in Coroner.

You can also create a new language code and set the languae in the config.
